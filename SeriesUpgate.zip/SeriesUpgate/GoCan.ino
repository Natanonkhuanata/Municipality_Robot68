void Can1() {
  Trac2Speed(Speed, 400);
  June();
  BackwardSpeedTime(30, 180);
  MotorStop();
  SR(TurnSpeed);
  delay(78);
  MotorStop();
  LadyGrip();
  ForwardSpeedTime(SlowSpeed,100);
  Grip();
  LedyPut();
}