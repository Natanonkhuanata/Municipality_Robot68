#define BrakeSpeedIMU 100
#define BrakeTimeIMU 10


void zeroYaw()  //กำหนดมุมเริ่มต้นระนาบพื้นโลกเป็น 0
{
  Serial1.begin(115200);
  delay(100);
  Serial1.write(0XA5);
  Serial1.write(0X54);
  delay(60);
  Serial1.write(0XA5);
  Serial1.write(0X55);
  delay(60);
  Serial1.write(0XA5);
  Serial1.write(0X52);
  delay(60);
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  getIMU();
  beep();
}
bool getIMU() {  //0-360 องศา
  while (Serial1.available()) {
    rxBuf[rxCnt] = Serial1.read();
    if (rxCnt == 0 && rxBuf[0] != 0xAA) return false;
    rxCnt++;
    if (rxCnt == 8) {
      rxCnt = 0;
      if (rxBuf[0] == 0xAA && rxBuf[7] == 0x55) {
        pvYaw = (int16_t)(rxBuf[1] << 8 | rxBuf[2]) / 100.f;
        if (pvYaw < 0) pvYaw = 360.000 + pvYaw;  //เพิ่มเติม
        return true;
      }
    }
  }
  return false;
}
void ShowYaw() {  //0-360 หมุนทวนเข็มนาฬิกา
  oled.clear();
  while (1) {
    if (getIMU()) {
      oled.text(0, 0, "Yaw=%f  ", pvYaw);
      oled.show();
    }
  }
}
void TurnLeftDegree(int TurnSpeed, float Degree, int Origin)  //เลี้ยวซ้ายใช้เข็มทิศ Degree 0-359
{                                                             //0:เคลียร์มุมเริ่มต้น 1:ไม่เคลียร์มุมเริ่มต้น 2:เคลียร์มุมเริ่มต้น
  int Status = 0;
  MotorStop();
  if (Origin != 1) zeroYaw();
  getIMU();
  float A = pvYaw;
  if (A < 0) A += 360;
  SL(TurnSpeed);
  while (Status == 0) {
    if (getIMU()) {
      if ((pvYaw >= Degree - 15) && (pvYaw <= Degree - 0)) {
        Status = 1;
      } else if (Degree == 0) {  //ในกรณี Degree เช็คค่าได้ 0
        if ((pvYaw >= 345) && (pvYaw <= 360)) {
          Status = 1;
        }
      }
    }
  }
  ///////////////////////////////////////////////เช็คมุม อีกรอบว่าเเม่นยำรึยัง
  Status = 0;
  SR(45);
  while (Status == 0) {
    if (getIMU()) {
      if ((pvYaw >= Degree - 0.7) && (pvYaw <= Degree + 0.7)) {
        Status = 1;
      } else if (Degree == 0) {
        if ((pvYaw >= 355) || (pvYaw <= 5)) {
          Status = 1;
        }
      }
    }
  }
  MotorStop();
}
void TurnRightDegree(int TurnSpeed, float Degree, int Origin)  //เลี้ยวซ้ายใช้เข็มทิศ Degree 0-359
{                                                              //0:เคลียร์มุมเริ่มต้น 1:ไม่เคลียร์มุมเริ่มต้น 2:เคลียร์มุมเริ่มต้น
  int Status = 0;
  MotorStop();
  if (Origin != 1) zeroYaw();
  SR(TurnSpeed);
  for (int i = 0; i < 10; i++) {
    getIMU();
  }
  while (Status == 0) {
    if (getIMU()) {
      if (Degree == 0) break;
      else if ((pvYaw <= Degree + 15) && (pvYaw >= Degree)) {
        Status = 1;
      } else if (Degree >= 350) {
        if ((pvYaw <= Degree - 350) || (pvYaw >= 350)) Status = 1;
      }
    }
  }
  Status = 0;
  SL(45);
  while (Status == 0) {
    if (getIMU()) {
      if (Degree == 0) break;
      else if ((pvYaw <= Degree + 1) && (pvYaw >= Degree - 1)) {
        Status = 1;
      } else if (Degree >= 355) {
        if ((pvYaw <= Degree - 355) || (pvYaw >= Degree - 2)) Status = 1;
      }
    }
  }
  MotorStop();
}
