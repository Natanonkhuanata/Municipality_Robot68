void GoCan1() {

  TracSpeedTime(Speed,910);
  MotorStop();
  TurnLeftDegree(TurnSpeed,90,1);
  OffMotor();
  FunctionJuneBack();
}
void GoPoints1() {
 
}
void GoCan2() {
  

  
}
void GoPoints2() {
  
}