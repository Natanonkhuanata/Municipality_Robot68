
void distance() {
  Sonar = analog(PA2);
  oled.text(3, 3, "distance= %l", Sonar / 40);
  delay(100);
  oled.show();
}
void ReadSonar() {
  Sonar = analog(PA2);
}
void BackwardSonar() {
  while (1) {
    ReadSonar();
    Backward();
    if(Sonar >=9)break;
  }
  sound(200,500);
}