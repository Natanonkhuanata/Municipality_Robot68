void PutCan() {
  if (Color == 1) {
    TL(TurnSpeed);
    delay(120);
    MotorStop();
    TracSonar(40, 9);
    MotorStop();
    downhelp();
    MotorStop();
    Put();
    MotorStop();
    sound(1000, 500);
    MotorStop();
    BackwardSpeedTime(25, 200);
    MotorStop();
    ReadyPut();
    MotorStop();
  } else if (Color == 2) {
    TracSonar(40, 8);
    MotorStop();
    downhelp();
    MotorStop();
    getIMU();
    if (pvYaw > 270) {
      TL(50);
      delay(40);
    } else {
      TR(50);
      delay(40);
    }
    MotorStop();
    Put();
    MotorStop();
    sound(1000, 500);
    MotorStop();
    BackwardSpeedTime(25, 200);
    MotorStop();
    ReadyPut();
    MotorStop();
  } else if (Color == 3) {
    MotorStop();
    TR(TurnSpeed);
    delay(120);
    MotorStop();
    TracSonar(40, 9);
    MotorStop();
    downhelp();
    MotorStop();
    Put();
    MotorStop();
    sound(1000, 500);
    MotorStop();
    BackwardSpeedTime(25, 200);
    MotorStop();
    ReadyPut();
    MotorStop();
  }
  /*
  Trac2SpeedBack(Speed,500);
  ForwardSpeedTime(30,400);
  MotorStop();
  TurnLeftDegree(TurnSpeed,90,0);
  MotorStop();
  FunctionJuneBack();
  MotorStop();
  */
}